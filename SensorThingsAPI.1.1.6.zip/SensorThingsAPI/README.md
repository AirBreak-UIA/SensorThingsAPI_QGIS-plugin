# SensorThings API plugin for QGIS
Plugin QGIS l'interrogazione delle postazioni Frost
<br>
<br>
## License
GNU GPL 3
<br>
<br>
<br>
<br>
Sviluppato da: Dedagroup S.p.A. (2022)
